<#
.SYNOPSIS
    STM32 Development Environment Diagnostics (Arduino CLI, OpenOCD & ST-Link)
.DESCRIPTION
    Checks for the presence of Arduino CLI, installed STM32 platforms, GCC compilers,
    OpenOCD flashing utilities, active USB COM ports, and ST-Link drivers.
#>

Write-Host "=================================================" -ForegroundColor Cyan
Write-Host "    STM32 Development Environment Diagnostics    " -ForegroundColor Cyan
Write-Host "=================================================" -ForegroundColor Cyan

# 1. Check Arduino CLI
$arduinoCli = $null
$cliCmd = Get-Command "arduino-cli" -ErrorAction SilentlyContinue
if ($cliCmd) {
    $arduinoCli = $cliCmd.Source
} elseif (Test-Path "C:\Program Files\Arduino CLI\arduino-cli.exe") {
    $arduinoCli = "C:\Program Files\Arduino CLI\arduino-cli.exe"
}

if ($arduinoCli) {
    $ver = & $arduinoCli version
    Write-Host "[FOUND] Arduino CLI: $arduinoCli ($ver)" -ForegroundColor Green
} else {
    Write-Host "[MISSING] Arduino CLI not found in PATH or 'C:\Program Files\Arduino CLI\'." -ForegroundColor Yellow
}

# 2. Check Installed STM32 Arduino Platform
$stm32CorePath = "$env:LOCALAPPDATA\Arduino15\packages\STMicroelectronics"
if (Test-Path $stm32CorePath) {
    Write-Host "[FOUND] Arduino STM32 Core: $stm32CorePath" -ForegroundColor Green
} else {
    Write-Host "[INFO] Arduino STM32 core package not yet installed." -ForegroundColor DarkGray
}

# 3. Check for xPack OpenOCD (from Arduino toolchain or PATH)
$openocdPath = $null
$openocdCmd = Get-Command "openocd" -ErrorAction SilentlyContinue
if ($openocdCmd) {
    $openocdPath = $openocdCmd.Source
} else {
    $foundOcd = Get-ChildItem -Path "$env:LOCALAPPDATA\Arduino15\packages\STMicroelectronics\tools\xpack-openocd" -Filter "openocd.exe" -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($foundOcd) { $openocdPath = $foundOcd.FullName }
}

if ($openocdPath) {
    Write-Host "[READY] OpenOCD Debugger & Flasher: $openocdPath" -ForegroundColor Green
} else {
    Write-Host "[--] OpenOCD not found." -ForegroundColor DarkGray
}

# 4. Check for ARM GCC Compiler (from Arduino toolchain or PATH)
$gccPath = $null
$gccCmd = Get-Command "arm-none-eabi-gcc" -ErrorAction SilentlyContinue
if ($gccCmd) {
    $gccPath = $gccCmd.Source
} else {
    $foundGcc = Get-ChildItem -Path "$env:LOCALAPPDATA\Arduino15\packages\STMicroelectronics\tools\xpack-arm-none-eabi-gcc" -Filter "arm-none-eabi-gcc.exe" -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($foundGcc) { $gccPath = $foundGcc.FullName }
}

if ($gccPath) {
    Write-Host "[READY] ARM GCC Compiler: $gccPath" -ForegroundColor Green
} else {
    Write-Host "[--] ARM GCC compiler not found." -ForegroundColor DarkGray
}

# 5. Check for STM32_Programmer_CLI (STM32CubeIDE)
$stm32Cli = $null
$stm32Cmd = Get-Command "STM32_Programmer_CLI" -ErrorAction SilentlyContinue
if ($stm32Cmd) {
    $stm32Cli = $stm32Cmd.Source
} else {
    $foundProg = Get-ChildItem -Path "C:\ST\STM32CubeIDE*","${env:ProgramFiles}\STMicroelectronics\*","${env:ProgramFiles(x86)}\STMicroelectronics\*" -Filter "STM32_Programmer_CLI.exe" -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($foundProg) { $stm32Cli = $foundProg.FullName }
}

if ($stm32Cli) {
    Write-Host "[FOUND] STM32_Programmer_CLI: $stm32Cli" -ForegroundColor Green
} else {
    Write-Host "[INFO] STM32CubeProgrammer not installed (using OpenOCD & Arduino CLI instead)." -ForegroundColor Cyan
}

# 6. Check Active COM Ports (ST-Link VCP / USB-TTL)
Write-Host "`nScanning Active Serial (COM) Ports:" -ForegroundColor Cyan
try {
    $ports = [System.IO.Ports.SerialPort]::GetPortNames()
    if ($ports.Count -gt 0) {
        foreach ($port in $ports) {
            Write-Host "  [FOUND] Serial Port: $port" -ForegroundColor Green
        }
    } else {
        Write-Host "  [INFO] No active COM ports detected. Connect USB-TTL or ST-Link VCP." -ForegroundColor Yellow
    }
} catch {
    Write-Host "  [INFO] Unable to query COM ports." -ForegroundColor DarkGray
}

# 7. Check for Bundled ST-Link Driver
$driverZip = ".\.agents\skills\stm32\drivers\stsw-link009.zip"
if (Test-Path $driverZip) {
    Write-Host "`n[READY] Bundled ST-LINK Driver Package: $driverZip" -ForegroundColor Green
}

Write-Host "`nDiagnostics Complete.`n" -ForegroundColor Cyan
